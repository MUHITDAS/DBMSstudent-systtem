<?php include 'db_connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Student</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-5">
  <div class="card p-4 shadow-lg">
    <h2 class="text-success mb-3">Add New Student</h2>
    <form method="post">
      <input type="text" name="name" class="form-control mb-2" placeholder="Name" required>
      <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
      <input type="text" name="contact_number" class="form-control mb-2" placeholder="Contact Number" required>
      <input type="text" name="address_line" class="form-control mb-2" placeholder="Address" required>
      <input type="number" step="0.01" min="0" max="4" name="gpa" class="form-control mb-2" placeholder="GPA (0.00 - 4.00)" required>
      <select name="department_id" class="form-control mb-3" required>
        <option value="">Select Department</option>
        <?php
          $res = $conn->query("SELECT * FROM tbl_departments");
          while ($row = $res->fetch_assoc()) {
              echo "<option value='{$row['department_id']}'>{$row['department_name']}</option>";
          }
        ?>
      </select>
      <button type="submit" name="submit" class="btn btn-primary">Add Student</button>
    </form>
  </div>
</div>
</body>
</html>

<?php
if (isset($_POST['submit'])) {
    $stmt = $conn->prepare("INSERT INTO tbl_student_info (name, email, contact_number, address, gpa, department_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssdi", $_POST['name'], $_POST['email'], $_POST['contact_number'], $_POST['address_line'], $_POST['gpa'], $_POST['department_id']);
    $stmt->execute();
    echo "<script>alert('Student Added'); window.location='view_students.php';</script>";
}
?>
