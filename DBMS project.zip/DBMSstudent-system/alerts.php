<?php include 'db_connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Alerts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-5">
    <div class="alert-box">
        <h2 class="mb-4 text-center text-danger">
            <span class="header-icon">⚠️</span> Low Attendance Alerts
        </h2>
        <table class="table table-hover table-bordered align-middle">
            <thead>
                <tr>
                    <th>👨‍🎓 Student ID</th>
                    <th>📘 Course ID</th>
                    <th>💬 Message</th>
                    <th>📊 Attendance %</th>
                    <th>⏰ Timestamp</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $alerts = $conn->query("SELECT * FROM tbl_alerts ORDER BY student_id ASC");

                if ($alerts && $alerts->num_rows > 0) {
                    while ($row = $alerts->fetch_assoc()) {
                        $student_id = $row['student_id'];
                        $course_id = $row['course_id'];

                        // Get total and present counts
                        $total_q = $conn->query("SELECT COUNT(*) as total FROM tbl_attendance WHERE student_id='$student_id' AND course_id='$course_id'");
                        $present_q = $conn->query("SELECT COUNT(*) as present FROM tbl_attendance WHERE student_id='$student_id' AND course_id='$course_id' AND status='Present'");

                        $total = $total_q->fetch_assoc()['total'];
                        $present = $present_q->fetch_assoc()['present'];

                        // Calculate percentage
                        if ($total > 0) {
                            $attendance_percent = round(($present / $total) * 100, 0);
                        } else {
                            $attendance_percent = 0;
                        }

                        // Decide message
                        if ($attendance_percent == 100) {
                            $message = "✅ Student attended 100%";
                            $badgeClass = "bg-success";
                        } elseif ($attendance_percent == 0) {
                            $message = "⚠️ No attendance records found";
                            $badgeClass = "bg-secondary";
                        } else {
                            $message = "⚠️ Low attendance: $attendance_percent%";
                            $badgeClass = "bg-warning text-dark";
                        }

                        echo "<tr>
                            <td><span class='badge bg-primary'>{$student_id}</span></td>
                            <td><span class='badge bg-info text-dark'>{$course_id}</span></td>
                            <td><span class='badge {$badgeClass}'>{$message}</span></td>
                            <td><span class='badge bg-light text-dark'>{$attendance_percent}%</span></td>
                            <td><span class='badge bg-secondary'>{$row['created_at']}</span></td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center text-muted'>📭 No alerts found</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
