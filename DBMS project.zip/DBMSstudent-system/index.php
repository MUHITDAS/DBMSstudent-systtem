<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HOMEPAGE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow-lg">
        <div class="card-body">
            <h1 class="text-center text-primary mb-4">📚 Student Management System</h1>
            <div class="list-group">
                <a href="add_student.php" class="list-group-item list-group-item-action">➕ Add Student</a>
                <a href="view_students.php" class="list-group-item list-group-item-action">👨‍🎓 View Students</a>
                <a href="add_attendance.php" class="list-group-item list-group-item-action">✅ Mark Attendance</a>
                <a href="view_reports.php" class="list-group-item list-group-item-action">📊 Reports</a>
                <a href="alerts.php" class="list-group-item list-group-item-action">⚠️ Attendance Alerts</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>

