<?php include 'db_connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-5">
    <h2 class="mb-4">Mark Attendance</h2>
    <form action="" method="post">
        <select name="student_id" class="form-select mb-3" required>
            <option value="" disabled selected>Select Student</option>
            <?php
            $students = $conn->query("SELECT student_id, name FROM tbl_student_info");
            while ($s = $students->fetch_assoc()) {
                echo "<option value='{$s['student_id']}'>{$s['name']}</option>";
            }
            ?>
        </select>
        <select name="course_id" class="form-select mb-3" required>
            <option value="" disabled selected>Select Course</option>
            <?php
            $courses = $conn->query("SELECT course_id, course_name FROM tbl_courses");
            while ($c = $courses->fetch_assoc()) {
                echo "<option value='{$c['course_id']}'>{$c['course_name']}</option>";
            }
            ?>
        </select>
        <input type="date" name="date" class="form-control mb-3" required>
        <select name="status" class="form-select mb-3">
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
        </select>
        <button type="submit" name="submit" class="btn btn-success">Submit</button>
    </form>
</div>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
    $stmt = $conn->prepare("INSERT INTO tbl_attendance (student_id, course_id, date, status) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $_POST['student_id'], $_POST['course_id'], $_POST['date'], $_POST['status']);
    $stmt->execute();
    echo "<script>alert('Attendance marked!'); window.location='add_attendance.php';</script>";
}
?>