-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2025 at 02:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_first_class`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_gpa` (IN `stu_id` INT)   BEGIN
    DECLARE calculated_gpa DECIMAL(3,2);

    SELECT AVG(
        CASE 
            WHEN grade = 'A' THEN 4
            WHEN grade = 'B' THEN 3
            WHEN grade = 'C' THEN 2
            WHEN grade = 'D' THEN 1
            ELSE 0
        END
    ) INTO calculated_gpa
    FROM tbl_results
    WHERE student_id = stu_id;

    UPDATE tbl_student_info
    SET gpa = calculated_gpa
    WHERE student_id = stu_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_alerts`
--

CREATE TABLE `tbl_alerts` (
  `alert_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_alerts`
--

INSERT INTO `tbl_alerts` (`alert_id`, `student_id`, `course_id`, `message`, `created_at`) VALUES
(1, 2, 1, 'This student attend every class', '2025-04-19 08:39:56'),
(2, 6, 2, 'This student attend every class', '2025-04-19 08:39:56'),
(3, 12, 3, 'This student attend every class', '2025-04-19 12:00:41'),
(4, 13, 4, 'This student attend every class', '2025-04-19 12:00:41'),
(23, 27, 1, 'Low attendance: 66.67%', '2025-04-20 12:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

CREATE TABLE `tbl_attendance` (
  `attendance_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` enum('Present','Absent') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_attendance`
--

INSERT INTO `tbl_attendance` (`attendance_id`, `student_id`, `course_id`, `date`, `status`) VALUES
(1, 2, 1, '2025-04-19', 'Present'),
(2, 6, 2, '2025-04-19', 'Present'),
(6, 12, 3, '2025-04-19', 'Present'),
(7, 13, 4, '2025-04-19', 'Present'),
(41, 27, 1, '2025-04-20', 'Present'),
(42, 27, 1, '2025-04-20', 'Present'),
(43, 27, 1, '2025-04-20', 'Absent'),
(44, 27, 1, '2025-04-22', 'Present');

--
-- Triggers `tbl_attendance`
--
DELIMITER $$
CREATE TRIGGER `trg_low_attendance` AFTER INSERT ON `tbl_attendance` FOR EACH ROW BEGIN
    DECLARE total_classes INT;
    DECLARE present_classes INT;
    DECLARE attendance_percent DECIMAL(5,2);

    SELECT COUNT(*) INTO total_classes
    FROM tbl_attendance
    WHERE student_id = NEW.student_id AND course_id = NEW.course_id;

    SELECT COUNT(*) INTO present_classes
    FROM tbl_attendance
    WHERE student_id = NEW.student_id AND course_id = NEW.course_id AND status = 'Present';

    SET attendance_percent = (present_classes / total_classes) * 100;

    IF attendance_percent < 75 THEN
        INSERT INTO tbl_alerts (student_id, course_id, message)
        VALUES (NEW.student_id, NEW.course_id, CONCAT('Low attendance: ', attendance_percent, '%'));
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_courses`
--

CREATE TABLE `tbl_courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_courses`
--

INSERT INTO `tbl_courses` (`course_id`, `course_name`, `department_id`) VALUES
(1, 'DBMS', 2),
(2, 'OOP', 6),
(3, 'TOC', 12),
(4, 'NM', 13);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_departments`
--

CREATE TABLE `tbl_departments` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_departments`
--

INSERT INTO `tbl_departments` (`department_id`, `department_name`) VALUES
(2, 'CSE'),
(6, 'CSE'),
(12, 'CSE'),
(13, 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_enrollments`
--

CREATE TABLE `tbl_enrollments` (
  `enrollment_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `enrollment_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_enrollments`
--

INSERT INTO `tbl_enrollments` (`enrollment_id`, `student_id`, `course_id`, `enrollment_date`) VALUES
(1, 2, 1, '2025-04-19'),
(2, 6, 2, '2025-04-19'),
(3, 12, 3, '2025-04-19'),
(4, 13, 4, '2025-04-19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_results`
--

CREATE TABLE `tbl_results` (
  `result_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `grade` varchar(2) DEFAULT NULL,
  `semester` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_results`
--

INSERT INTO `tbl_results` (`result_id`, `student_id`, `course_id`, `grade`, `semester`) VALUES
(1, 2, 1, 'A', '3rd'),
(2, 6, 2, 'A', '3rd'),
(3, 12, 3, 'A', '3rd'),
(4, 13, 4, 'A', '3rd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_info`
--

CREATE TABLE `tbl_student_info` (
  `student_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `gpa` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_student_info`
--

INSERT INTO `tbl_student_info` (`student_id`, `name`, `email`, `contact_number`, `department_id`, `address`, `gpa`) VALUES
(2, 'Sayad safi', 'sayadsafi@gmail.com', '01745673890', 2, 'Sylhet.', 3.50),
(6, 'Biplob hasan', 'bipolb@gmail.com', '01563637378', 6, 'Bogra', 3.50),
(12, 'Muhit Das', 'muhitdas@gmail.com', '01743473890', 12, 'Kajolsha, Sylhet.', 3.50),
(13, 'Shakib Rahman', 'shakibrahman@gmail.com', '015636373783', 13, 'Habiganj.', 3.50),
(27, 'Shuvo', 'shuvo@gmail.com', '01735373862', 2, 'Sylhet', 3.79);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_top_students_per_department`
-- (See below for the actual view)
--
CREATE TABLE `vw_top_students_per_department` (
`student_id` int(11)
,`name` varchar(50)
,`department_name` varchar(100)
,`gpa` decimal(4,4)
);

-- --------------------------------------------------------

--
-- Structure for view `vw_top_students_per_department`
--
DROP TABLE IF EXISTS `vw_top_students_per_department`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_top_students_per_department`  AS SELECT `s`.`student_id` AS `student_id`, `s`.`name` AS `name`, `d`.`department_name` AS `department_name`, avg(case when `r`.`grade` = 'A' then 4 when `r`.`grade` = 'B' then 3 when `r`.`grade` = 'C' then 2 when `r`.`grade` = 'D' then 1 else 0 end) AS `gpa` FROM ((`tbl_results` `r` join `tbl_student_info` `s` on(`r`.`student_id` = `s`.`student_id`)) join `tbl_departments` `d` on(`s`.`department_id` = `d`.`department_id`)) GROUP BY `s`.`student_id` HAVING `gpa` >= 3.5 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_alerts`
--
ALTER TABLE `tbl_alerts`
  ADD PRIMARY KEY (`alert_id`);

--
-- Indexes for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD PRIMARY KEY (`attendance_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `tbl_attendance_ibfk_2` (`course_id`);

--
-- Indexes for table `tbl_courses`
--
ALTER TABLE `tbl_courses`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `tbl_departments`
--
ALTER TABLE `tbl_departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `tbl_enrollments`
--
ALTER TABLE `tbl_enrollments`
  ADD PRIMARY KEY (`enrollment_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `tbl_results`
--
ALTER TABLE `tbl_results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `tbl_student_info`
--
ALTER TABLE `tbl_student_info`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `department_id` (`department_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_alerts`
--
ALTER TABLE `tbl_alerts`
  MODIFY `alert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `tbl_courses`
--
ALTER TABLE `tbl_courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_departments`
--
ALTER TABLE `tbl_departments`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_enrollments`
--
ALTER TABLE `tbl_enrollments`
  MODIFY `enrollment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_results`
--
ALTER TABLE `tbl_results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_student_info`
--
ALTER TABLE `tbl_student_info`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD CONSTRAINT `tbl_attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `tbl_student_info` (`student_id`),
  ADD CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `tbl_courses` (`course_id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_courses`
--
ALTER TABLE `tbl_courses`
  ADD CONSTRAINT `tbl_courses_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `tbl_departments` (`department_id`);

--
-- Constraints for table `tbl_enrollments`
--
ALTER TABLE `tbl_enrollments`
  ADD CONSTRAINT `tbl_enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `tbl_student_info` (`student_id`),
  ADD CONSTRAINT `tbl_enrollments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `tbl_courses` (`course_id`);

--
-- Constraints for table `tbl_results`
--
ALTER TABLE `tbl_results`
  ADD CONSTRAINT `tbl_results_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `tbl_student_info` (`student_id`),
  ADD CONSTRAINT `tbl_results_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `tbl_courses` (`course_id`);

--
-- Constraints for table `tbl_student_info`
--
ALTER TABLE `tbl_student_info`
  ADD CONSTRAINT `tbl_student_info_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `tbl_departments` (`department_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
