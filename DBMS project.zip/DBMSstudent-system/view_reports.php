<?php include 'db_connect.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-5">
    <h2 class="mb-4">Reports</h2>

    <div class="mb-4">
        <h4 class="text-primary">Average GPA by Course</h4>
        <table class="table table-bordered table-striped">
            <thead class="table-info text-center">
                <tr><th>Course</th><th>Average GPA</th></tr>
            </thead>
            <tbody>
                <?php
                $gpa = $conn->query("SELECT c.course_name, AVG(CASE grade WHEN 'A' THEN 4 WHEN 'B' THEN 3 WHEN 'C' THEN 2 WHEN 'D' THEN 1 ELSE 0 END) AS avg_gpa FROM tbl_results r JOIN tbl_courses c ON r.course_id = c.course_id GROUP BY r.course_id");
                while ($row = $gpa->fetch_assoc()) {
                    echo "<tr><td>{$row['course_name']}</td><td>{$row['avg_gpa']}</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <div class="mb-4">
        <h4 class="text-primary">Most Enrolled Courses</h4>
        <table class="table table-bordered table-striped">
            <thead class="table-warning text-center">
                <tr><th>Course</th><th>Total Enrollments</th></tr>
            </thead>
            <tbody>
                <?php
                $enroll = $conn->query("SELECT c.course_name, COUNT(*) AS total FROM tbl_enrollments e JOIN tbl_courses c ON e.course_id = c.course_id GROUP BY e.course_id ORDER BY total DESC");
                while ($row = $enroll->fetch_assoc()) {
                    echo "<tr><td>{$row['course_name']}</td><td>{$row['total']}</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <div>
        <h4 class="text-primary">Monthly Attendance Percentage</h4>
        <table class="table table-bordered table-striped">
            <thead class="table-success text-center">
                <tr><th>Student</th><th>Month</th><th>Attendance %</th></tr>
            </thead>
            <tbody>
                <?php
                $attendance = $conn->query("SELECT s.name, DATE_FORMAT(a.date, '%Y-%m') as month, ROUND(SUM(a.status = 'Present') / COUNT(*) * 100, 2) as percent FROM tbl_attendance a JOIN tbl_student_info s ON a.student_id = s.student_id GROUP BY a.student_id, month");
                while ($row = $attendance->fetch_assoc()) {
                    echo "<tr><td>{$row['name']}</td><td>{$row['month']}</td><td>{$row['percent']}%</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>